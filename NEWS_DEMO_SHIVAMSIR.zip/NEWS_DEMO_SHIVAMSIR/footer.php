<div id ="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
            <span>© Copyright 2019 News | Powered by <a href="#">Rise Web solution</a></span>
            </div>
        </div>
    </div>
</div>
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>
